import streamlit as st
import pandas as pd
import os
from tpot import TPOTRegressor, TPOTClassifier
from sklearn.model_selection import train_test_split
import pickle

def preprocess_data(df):
    df = df.dropna()
    from sklearn.preprocessing import LabelEncoder
    label_encoder = LabelEncoder()
    for column in df.columns:
        if df[column].dtype == 'object':
            df[column] = label_encoder.fit_transform(df[column])
    return df

if os.path.exists('./dataset.csv'):
    df = pd.read_csv('dataset.csv', index_col=None)

with st.sidebar:
    st.image("https://i.ytimg.com/vi/-ZOIywSCNR8/maxresdefault.jpg")
    st.title("AutoML with TPOT")
    choice = st.radio("Navigation", [
        "Upload", "Profiling", "Regression Modelling", "Regression Download",
        "Classification Modelling", "Classification Download", "Test Data"])
    st.info("This project application helps you build and explore your data.")

if choice == "Upload":
    st.title("Upload Your Dataset")
    file = st.file_uploader("Upload Your Dataset")
    if file:
        df = pd.read_csv(file, index_col=None)
        df.to_csv('dataset.csv', index=None)
        st.dataframe(df)

if choice == "Regression Modelling":
    chosen_target = st.selectbox('Choose the Target Column', df.columns)
    if st.button('Run Modelling'):
        df_preprocessed = preprocess_data(df)
        X = df_preprocessed.drop(columns=[chosen_target])
        y = df_preprocessed[chosen_target]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        model = TPOTRegressor(generations=5, population_size=20, verbosity=2)
        model.fit(X_train, y_train)
        st.success("Model trained successfully!")
        
        with open('tpot_regressor.pkl', 'wb') as f:
            pickle.dump(model, f)

if choice == "Classification Modelling":
    chosen_target = st.selectbox('Choose the Target Column', df.columns)
    if st.button('Run Modelling'):
        df_preprocessed = preprocess_data(df)
        X = df_preprocessed.drop(columns=[chosen_target])
        y = df_preprocessed[chosen_target]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        model = TPOTClassifier(generations=5, population_size=20, verbosity=2)
        model.fit(X_train, y_train)
        st.success("Model trained successfully!")
        
        with open('tpot_classifier.pkl', 'wb') as f:
            pickle.dump(model, f)

if choice == "Regression Download":
    with open('tpot_regressor.pkl', 'rb') as f:
        st.download_button('Download Model', f, file_name="tpot_regressor.pkl")

if choice == "Classification Download":
    with open('tpot_classifier.pkl', 'rb') as f:
        st.download_button('Download Model', f, file_name="tpot_classifier.pkl")

if choice == "Test Data":
    model_file = st.file_uploader("Upload your trained TPOT model", type=["pkl"])
    if model_file:
        model = pickle.load(model_file)
        file = st.file_uploader("Upload Test Dataset")
        if file:
            df_test = pd.read_csv(file, index_col=None)
            df_test_preprocessed = preprocess_data(df_test)
            predictions = model.predict(df_test_preprocessed)
            st.write("Predictions:")
            st.dataframe(predictions)
